<?php
//database connection
$mysqli=new mysqli("localhost", "yaj", "439437", "yaj");
?>
