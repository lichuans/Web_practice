<?php
//starting session
session_start();

//if the session for username has not been set, initialise it
if(!isset($_SESSION['mode'])){
	$_SESSION['mode']="";
}
//save username in the session 
$mode=$_SESSION['mode'];

if(!isset($_SESSION['id'])){
	$_SESSION['id']="";
}
//save username in the session 
$id=$_SESSION['id'];

?>
