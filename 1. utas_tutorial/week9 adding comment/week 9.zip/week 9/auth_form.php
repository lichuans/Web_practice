<?php
include("session.php");
if($_POST['edit']){
    $mode=$_POST['edit'];
        $_SESSION['mode']=$mode;
                  };
if($_POST['delete']){
    $mode=$_POST['delete'];
        $_SESSION['mode']=$mode;
                  };
//printf("okokookok,%s,%s",$id,$mode);
$id=$_POST['id'];
printf($id);
$_SESSION['id']=$id;
include("db_conn.php");

if($mode==delete)
{
    $query = "DELETE FROM guestbook WHERE ID='$id'";
    $result = $mysqli->query($query);
    $mysqli->close();
}

?>
    <html>

    <head>
        <title>Guestbook</title>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <h1>Authentication :</h1>
        [<a href="./list.php">Go Back to list</a>]

        <form action="./form.php" method="post">
            <table id="form">
                <tr>
                    <!-- you should let the user know which activity (edit or delete) they do-->
                    <td colspan="2"> Enter the password to
                        <?php 
            echo $mode;
    	?> the comment.</td>
                </tr>
                <tr>
                    <!-- you should show the ID number of the selected comment in the disabled textfield. Disabled textfield is not clickable-->
                    <td class="details">ID</td>
                    <td><input name="id" value="<?php echo $id; ?>" readonly /></td>
                </tr>
                <tr>
                    <!--password field for authenticating-->
                    <td class="details">Password</td>
                    <td><input name="password" type="password"></td>
                </tr>
                <tr>
                    <td class="submit" colspan="2">
                        <input type="submit" name="submit" value="Submit">
                        <input type="reset" value="Reset">
                    </td>
                </tr>
            </table>
        </form>
    </body>

    </html>
